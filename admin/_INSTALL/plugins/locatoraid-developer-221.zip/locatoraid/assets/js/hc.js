jQuery(document).on( 'click', 'a.hc-confirm', function(event)
{
	return window.confirm("Are you sure?");
});
