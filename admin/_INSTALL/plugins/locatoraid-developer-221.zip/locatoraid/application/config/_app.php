<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$app = isset($GLOBALS['NTS_CONFIG']['_app_']) ? $GLOBALS['NTS_CONFIG']['_app_'] : 'lookuprunner';
$app_title = isset($GLOBALS['NTS_CONFIG']['_app_title_']) ? $GLOBALS['NTS_CONFIG']['_app_title_'] : 'Lookup Runner';
$app_core = 'lookuprunner';
