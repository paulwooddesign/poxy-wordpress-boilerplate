<?php
require( dirname(__FILE__) . '/index_action.php' );
$CI->output->_display();
//echo $CI->output->get_output();
