<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Locations extends Admin_controller_crud
{
	function __construct()
	{
		ini_set( 'auto_detect_line_endings', TRUE );

		$this->conf = array(
			'model'			=> 'Location_model',
			'path'			=> 'pro/admin/locations',
			'path-add'		=> 'admin/locations/add',
			'validation'	=> 'location',
			'export'		=> 'locations',
			);
		parent::__construct();

		$this->per_page = 12;
		$this->fields = $this->model->get_fields();
	}

	protected function _prepare_export()
	{
		$separator = $this->app_conf->get( 'csv_separator' );

	// header
		$headers = array();
		reset( $this->fields );
		foreach( $this->fields as $f )
		{
			$headers[ $f['name'] ] = $f['name'];
		}
		$headers[ 'latitude' ] = 'latitude';
		$headers[ 'longitude' ] = 'longitude';

	// entries
		$entries = $this->model->get_all( array_keys($headers) );
		unset( $headers['products'] );

	// check products
		$headers_products = array();
		for( $ii = 0; $ii < count($entries); $ii++ )
		{
			if( strlen($entries[$ii]['products']) )
			{
				$product_values = explode( ',', $entries[$ii]['products'] );
				$product_values = array_map( 'trim', $product_values );

				reset( $product_values );
				foreach( $product_values as $pn )
				{
					$header_name = 'product:' . $pn;
					$headers[$header_name] = $header_name;
					$headers_products[$header_name] = 1;
				}
			}
		}
		$headers_products = array_keys($headers_products);

	/* process entries */
		$product_func = create_function( '$e', 'return "product:" . trim($e);');
		for( $ii = 0; $ii < count($entries); $ii++ )
		{
			if( strlen($entries[$ii]['products']) )
			{
				$product_values = explode( ',', $entries[$ii]['products'] );
				$product_values = array_map( $product_func, $product_values );

				reset( $headers_products );
				foreach( $headers_products as $header_name )
				{
					if( in_array($header_name, $product_values) )
						$v = 'x';
					else
						$v = '';
					$entries[$ii][$header_name] = $v;
				}
			}
			unset( $entries[$ii]['products'] );
		}

		$data = array();
		$data[] = join( $separator, array_keys($headers) );
		for( $ii = 0; $ii < count($entries); $ii++ )
		{
			$data[] = hc_build_csv( array_values($entries[$ii]), $separator );
		}
		return $data;
	}

	function import( $do = FALSE )
	{
		$separator = $this->app_conf->get( 'csv_separator' );

		$this->data['include'] = $this->conf['path'] . '/import';
		$this->data['error'] = '';
		$this->data['message'] = array();

		$this->data['mandatory_fields'] = array();
		$this->data['other_fields'] = array();
		foreach( $this->fields as $f )
		{
			if( isset($f['required']) && $f['required'] )
				$this->data['mandatory_fields'][] = $f['name'];
			else
			{
				if( $f['name'] != 'products' )
				{
					$this->data['other_fields'][] = $f['name'];
				}
			}
		}
		$this->data['other_fields'][] = 'latitude';
		$this->data['other_fields'][] = 'longitude';

		$my_fields = array_merge( $this->data['mandatory_fields'], $this->data['other_fields'] );

		if( $do )
		{
			$mode = $this->input->post( 'mode' );
			// upload
			$file_name = 'userfile';

			if( isset($_FILES[$file_name]) && is_uploaded_file($_FILES[$file_name]['tmp_name']) )
			{
				$tmp_name = $_FILES[$file_name]['tmp_name'];
				$data = array();

				$parse_error = FALSE;
				if( ($handle = fopen($tmp_name, "r")) !== FALSE)
				{
					$line_no = 0;
					while( ($line = fgetcsv($handle, 1000, $separator)) !== FALSE )
					{
						// titles
						if( ! $line_no )
						{
							$prop_names = $line;
							for( $ii = 0; $ii < count($prop_names); $ii++ )
							{
								reset( $this->fields );
								foreach( $this->fields as $f )
								{
									if( strtolower($prop_names[$ii]) == $f['name'] )
									{
										$prop_names[$ii] = strtolower($prop_names[$ii]);
									}
								}
							}
//							$prop_names = array_map( 'strtolower', $prop_names );
							$prop_count = count( $prop_names );

						// check for mandatory fields
							$missing_fields = array();
							reset( $this->fields );
							foreach( $this->fields as $f )
							{
								if( isset($f['required']) && $f['required'] ){
									if( ! in_array($f['name'], $prop_names) ){
										$missing_fields[] = $f['name'];
										}
									}
							}
							if( $missing_fields )
							{
								$this->data['error'] = lang('location_import_error_fields_missing') . ': ' . join( ', ', $missing_fields );
								$parse_error = TRUE;
								break;
							}

						// check if any fields are not parsed
						// also check glued fields
							$glued_fields = array();
							$not_parsed_fields = array();
							reset( $prop_names );
							foreach( $prop_names as $f )
							{
								$f = trim( $f );
								if( ! $f )
									continue;
								if( ! in_array($f, $my_fields) )
								{
									if( preg_match('/^product\:(.+)$/', $f, $ma)  )
									{
										$to_glue = 'products';
										$value = $ma[1];
										$glued_fields[ $f ] = array( $to_glue, $value );
									}
									else
									{
										if( ! in_array(strtolower($f), $my_fields) )
											$not_parsed_fields[] = $f;
									}
								}
							}
							if( $not_parsed_fields )
							{
								$this->data['message'][] = lang('location_import_message_fields_not_recognized') . ': ' . join( ', ', $not_parsed_fields );
							}
						}
						else
						{
							$values = array();
							for( $i = 0; $i < $prop_count; $i++ )
							{
								$check_name = strtolower($prop_names[$i]);
//								$check_name = $prop_names[$i];
								if( in_array($check_name, $my_fields) )
								{
									if( isset($line[$i]) )
										$values[ $check_name ] = $line[$i];
									else
										$values[ $check_name ] = '';
								}
								elseif( isset($glued_fields[$prop_names[$i]]) )
								{
									if( isset($line[$i]) && strlen($line[$i]) )
									{
										$real_name = $glued_fields[$prop_names[$i]][0];
										$value = $glued_fields[$prop_names[$i]][1];
										if( ! isset($values[$real_name]) )
											$values[ $real_name ] = array();
										$values[ $real_name ][] = $value;
									}
								}
							}

						// glue glued fields
							reset( $glued_fields );
							foreach( array_keys($glued_fields) as $gf )
							{
								$real_name = $glued_fields[$gf][0];
								if( isset($values[$real_name]) && is_array($values[$real_name]) ){
									$values[$real_name] = implode( ', ', $values[$real_name] );
									}
							}
							$data[] = $values;
						}
						$line_no++;
					}
				fclose($handle);
				}

				if( ! $parse_error )
				{
					// finally import
					$loaded = 0;
					if( $mode != 'append' )
					{
						$this->app_conf->set( 'products', '' );
						$this->model->delete_all();
					}

					reset( $data );
					foreach( $data as $object )
					{
						if( $this->model->save($object) )
							$loaded++;
					}
					if( $loaded )
						$this->data['message'][] = lang('location_import_ok') . ': ' . $loaded;

				// redirect
					$this->session->set_flashdata( 'message', $this->data['message'] );
					ci_redirect( 'admin/locations' );
					exit;
				}
			}
			else
			{
				$this->data['error'] = lang('common_upload_error');
			}
		}
		$this->load->view( $this->template, $this->data);
	}
}

/* End of file customers.php */
/* Location: ./application/controllers/admin/categories.php */