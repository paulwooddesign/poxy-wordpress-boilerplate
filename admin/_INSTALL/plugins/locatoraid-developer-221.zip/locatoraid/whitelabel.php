<?php
$whitelabel['title'] = 'Your Company Name';
$whitelabel['url'] = 'http://www.yoursite.com';
?>
