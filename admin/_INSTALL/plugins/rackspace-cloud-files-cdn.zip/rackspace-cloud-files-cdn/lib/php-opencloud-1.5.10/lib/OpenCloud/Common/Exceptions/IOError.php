<?php

namespace OpenCloud\Common\Exceptions;

class IOError extends \Exception {}
