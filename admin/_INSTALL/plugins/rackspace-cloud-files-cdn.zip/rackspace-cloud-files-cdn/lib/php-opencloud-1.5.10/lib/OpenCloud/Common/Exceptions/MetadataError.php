<?php

namespace OpenCloud\Common\Exceptions;

class MetadataError extends \Exception {}
