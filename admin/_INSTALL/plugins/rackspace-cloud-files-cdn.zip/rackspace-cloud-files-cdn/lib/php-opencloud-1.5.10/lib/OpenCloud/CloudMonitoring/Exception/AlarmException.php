<?php

namespace OpenCloud\CloudMonitoring\Exception;

class AlarmException extends CloudMonitoringException
{
}