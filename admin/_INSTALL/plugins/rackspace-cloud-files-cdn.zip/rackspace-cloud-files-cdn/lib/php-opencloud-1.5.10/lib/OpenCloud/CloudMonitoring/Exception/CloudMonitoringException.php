<?php

namespace OpenCloud\CloudMonitoring\Exception;

use OpenCloud\Common\Exceptions\BaseException;

class CloudMonitoringException extends BaseException
{
}