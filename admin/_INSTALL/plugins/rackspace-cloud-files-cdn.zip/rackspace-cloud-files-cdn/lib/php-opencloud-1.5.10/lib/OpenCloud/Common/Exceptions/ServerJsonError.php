<?php

namespace OpenCloud\Common\Exceptions;

class ServerJsonError extends \Exception {}
