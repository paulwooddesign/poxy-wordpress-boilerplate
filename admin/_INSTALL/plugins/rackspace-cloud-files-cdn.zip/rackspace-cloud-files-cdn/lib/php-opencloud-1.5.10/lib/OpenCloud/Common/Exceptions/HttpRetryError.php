<?php

namespace OpenCloud\Common\Exceptions;

class HttpRetryError extends \Exception {}
