<?php

namespace OpenCloud\Common\Exceptions;

class UserDeleteError extends \Exception {}
