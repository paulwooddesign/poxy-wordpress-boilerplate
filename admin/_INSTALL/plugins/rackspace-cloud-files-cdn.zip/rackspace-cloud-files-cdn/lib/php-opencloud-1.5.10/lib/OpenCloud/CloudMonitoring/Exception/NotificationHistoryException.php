<?php

namespace OpenCloud\CloudMonitoring\Exception;

class NotificationHistoryException extends CloudMonitoringException
{
}