<?php

namespace OpenCloud\CloudMonitoring\Exception;

class TestException extends CloudMonitoringException
{
}