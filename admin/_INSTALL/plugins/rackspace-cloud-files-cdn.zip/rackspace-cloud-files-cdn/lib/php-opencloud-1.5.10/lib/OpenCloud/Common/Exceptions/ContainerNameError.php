<?php

namespace OpenCloud\Common\Exceptions;

class ContainerNameError extends \Exception {}
