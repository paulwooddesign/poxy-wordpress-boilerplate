<?php

namespace OpenCloud\Common\Exceptions;

class NameError extends \Exception {}
