<?php

namespace OpenCloud\Common\Exceptions;

class ContainerCreateError extends \Exception {}
