<?php

namespace OpenCloud\CloudMonitoring\Exception;

class EntityException extends CloudMonitoringException
{
}