<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div id="wp-pjax-toggle-container">
    
    <label for="wp-pjax-toggle" id="wp-pjax-toggle-label">
        <input id="wp-pjax-toggle" type="checkbox" CHECKED="CHECKED" />
        <span>Toggle PJAX</span> - <span id="wp-pjax-toggle-status" style="color: green;">Enabled</span>
    </label>
</div>
<script type="text/javascript"  charset="UTF-8">
          
</script>