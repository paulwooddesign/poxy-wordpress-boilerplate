<?php

/*
 * Define constants for WP-PJAX
 */


define('WP_PJAX_PLUGIN_INCLUDE_PATH', WP_PJAX_PLUGIN_PATH.'inc'.DIRECTORY_SEPARATOR);

define('WP_PJAX_OPTIONS_KEY', 'pe_wp_pjax_options');

define('WP_PJAX_CONFIG_PREFIX', 'wp-pjax-');

define('WP_PJAX_TRANIENT_PREFIX', 'wp_pjax_pc_');


DEFINE('WP_PJAX_PREFETCH_URLS_TANSIENT', 'wp_pjax_prefetch_urls');

